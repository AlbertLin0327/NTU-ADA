#!/usr/bin/env bash

# make neccesary file
make;

largest=0.0
smallest=1000000000000.0

#while true; do
	./testcase > in;
	./final < in > out;
	current=$(./checker in out)
	
	if [[ $(echo "$current < $smallest" | bc) ]]; then
		cat in > small.testcase 
		smallest=$current
		echo $smallest
	fi

	if [[ $(echo "$current > $largest" | bc) ]]; then 
		cat in > large.testcase
		largest=$current
		echo $largest
	fi
#done
